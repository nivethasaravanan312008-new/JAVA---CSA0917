package dao;
public class DuplicateRegistrationException extends Exception {
    public DuplicateRegistrationException(String m) { super(m); }
}
