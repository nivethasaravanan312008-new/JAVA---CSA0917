# CSA09-192525413-Assignment4 – Event-Driven GUI Design (CO4)

| | |
|---|---|
| **Name** | Mokshitha Kilari |
| **Register number** | 192525413 |
| **Course** | Programming in Java (CSA09) – B.Tech AIML, SIMATS Engineering |
| **Java version used** | OpenJDK 21.0.13 (`javac 21.0.13`) – any JDK 11+ works |
| **Report** | `docs/Assignment4_Report.pdf` (and `.docx`) |

## Folder layout
Each task has its own folder: `src/` = main code, `output/` = screenshots, terminal captures and result text files.

## Compile and run (from inside a task folder)
```bash
cd Task01
javac -d bin src/*.java
java -cp bin FeePaymentFrame          # the GUI
java -cp bin FeeServiceTest           # console tests
```
| Task | GUI / main class | Evidence driver (needs a display) |
|---|---|---|
| Task01 | `FeePaymentFrame` (faulty original: `BadFeeWindow`) | `ScreenshotDriver`, `FeeServiceTest` |
| Task02 | `AppointmentFrame` | `TraceDriver`, `CacheBenchmark` |
| Task03 | `LibrarySearchFrame` | `ResizeDriver` |
| Task04 | `DrawingPad` (`BrokenDrawingPad`, `HalfFixedPad` = before) | `PadDriver`; `demo/OverrideDemo.java` shows the @Override compile error |
| Task05 | `Converter1_FrameListener` … `Converter4_Lambda` | `ConverterDriver` |
| Task06 | `ui.Main` (`cd Task06/src; javac -d ../bin $(find . -name "*.java"); java -cp ../bin ui.Main`) | `ui.ScreenshotDriver`, `ui.Bench` |

Drivers write screenshots to `../output`, so run them from inside `src/`, e.g. `cd Task03/src && java -cp ../bin ResizeDriver`.

### Task 6 with MySQL
1. `mysql -u root -p < Task06/sql/schema.sql`
2. Download `mysql-connector-j` and add it to the class path.
3. `export DB_URL="jdbc:mysql://localhost:3306/campus_events" DB_USER=root DB_PASS=...`
4. `java -cp "bin:mysql-connector-j.jar" ui.Main`
Without `DB_URL` the app runs on an in-memory stand-in with the same rules.

## Result notes
- **Task01** – 9 design faults diagnosed; redesigned into FeePaymentFrame / FeeService / PaymentRepository. Service tests: 8 passed, 0 failed.
- **Task02** – event table, containment tree, pseudocode, real window-event trace; 200 department changes: ~1033 ms (DB each time) vs ~21 ms (Map).
- **Task03** – nested Border/Flow layouts; table viewport grows 172→452 px high while search row (35 px) and button row (37 px) stay fixed at 3 window sizes.
- **Task04** – 4 faults found and fixed; screenshots before/after (hide/restore) show dots lost vs kept.
- **Task05** – four handler styles; valid and invalid screenshots for each.
- **Task06** – 3-layer Swing + JDBC app; normal, invalid and duplicate registrations demonstrated; paging vs load-all benchmark.

## Honest notes (read before submitting)
- The terminal images in `output/terminal_*.png` are renderings of real command transcripts (the same text is in the matching `.txt`). For submission you may prefer to re-take them in your own terminal.
- Task 04/05 "as supplied" programs were reconstructed from the brief; swap in your instructor's files if they differ.
- Task 06 was executed on the in-memory DAO. The MySQL DAO and `sql/schema.sql` compile/are written but were **not run** – run them and add MySQL screenshots (`Task06/output/`).
- Minimise/restore in Task 04 was simulated by hide/show on a virtual display; replace with real minimise screenshots.
