# CSA09 – Assignment 5 (CO5): Data Persistence Engineering – Files and Databases

| | |
|---|---|
| **Name** | `<YOUR NAME>` |
| **Register number** | `<YOUR REGISTER NUMBER>` |
| **Course** | Programming in Java (CSA09) |
| **Java version used** | OpenJDK 21.0.13 (works on Java 17 or later – the code uses `record`) |
| **Database used for B2–B4** | Apache Derby 10.16.1.1 (embedded JDBC, jar files in `lib/`). Portable SQL – switches to MySQL with one JVM option (see below) |

Part A (design + pseudocode) is in the written report (`Assignment5_CO5_Report.docx`). This repository holds **Part B**: working Java code, input files, SQL, raw program output, measurement data and output screenshots.

## Repository layout

```
CSA09-<RegisterNumber>-Assignment5/
├── README.md
├── lib/                      Apache Derby jars (JDBC driver for the default database)
├── compile.sh / run_all.sh   build and run everything
├── commit_progressively.sh   creates one git commit per task
├── docs/                     written report (.docx) and chart images
├── tools/                    screenshot + chart generators
├── Task01/   B1  PassStore (add / find / list), HashMap alternative, line-count + search benchmarks
├── Task02/   B2  SQL-injection login demo, damaged bus-pass data tests
├── Task03/   B3  PassLoader (Statement / PreparedStatement / batch), insertion benchmark, schema.sql
└── Task04/   B4  Migration program, concurrency demo, scale benchmark (800,000 passes)
```

Every task folder contains `*.java` source, `data/` input files, `output/` raw program output (+ CSV measurements) and `screenshots/`.

## Compile and run

```bash
./compile.sh                      # javac -cp "lib/*" -d out Task*/*.java

# Task 01 - bus-pass file store (B1)
java -cp "out:lib/*" StoreDemo         # functional tests: normal / absent id / damaged line / missing file / torn write
java -cp "out:lib/*" LineCountBench    # 1 MB, 10 MB, 50 MB: unbuffered vs buffered vs readAllLines
java -cp "out:lib/*" SearchBench       # 1,000 -> 100,000 records: scan vs HashMap

# Task 02 - adversarial input (B2)
java -cp "out:lib/*" LoginDemo         # unsafe concatenated login vs PreparedStatement
java -cp "out:lib/*" DamagedDataTest   # wrong field count, non-numeric amount, empty line, ...

# Task 03 - JDBC performance (B3)
java -cp "out:lib/*" PassLoader        # 10 rows x 3 techniques, ResultSetMetaData, transaction failure test
java -Xmx2g -cp "out:lib/*" PassBench  # 1,000 / 10,000 / 100,000 rows (takes ~2.5 minutes)

# Task 04 - final decision (B4)
java -cp "out:lib/*" MakeLegacyFile    # creates the 8,000-line legacy file (5 deliberately bad lines)
java -cp "out:lib/*" Migrate           # validate + batch + transaction + DatabaseMetaData
java -cp "out:lib/*" ConcurrencyDemo   # file counter vs database counter, 8 threads
java -Xmx5g -cp "out:lib/*" ScaleBench # 800,000 passes, 12 campuses (needs ~5 GB heap, ~1 minute)
```
(On Windows use `;` instead of `:` in the class path.)

### Running against MySQL instead of Derby

`Task03/schema.sql` runs unchanged on MySQL 8.0.16+. Create the database, put `mysql-connector-j-*.jar` in `lib/` and add three JVM options:

```bash
java -Ddb.url="jdbc:mysql://localhost:3306/busdb" -Ddb.user=root -Ddb.pass=YOURPASSWORD \
     -cp "out:lib/*" PassLoader
```
Use a throw-away test database only (B2 deliberately contains an injectable query).

## Results at a glance (measured, see `Task*/output/`)

| Task | What was verified | Key result |
|---|---|---|
| **B1** file store | `find("P1003")` returns the record; `find("P1002")` (damaged) returns `null`; missing file and torn last line handled | Expected output reproduced exactly |
| **B1** line counting | 50 MB file, byte-by-byte | 52,428,801 `read()` calls, 11,535 ms unbuffered vs 6,401 calls / 21.6 ms with an 8 KB `byte[]` (**≈530× faster**) |
| **B1** search | scan-per-`find()` vs HashMap | scan grows linearly (≈27 ms/search at 100,000 records); HashMap lookup ≈ 0.0005 ms after a 115 ms load |
| **B2** login | 3 injection strings | Unsafe query accepted all 3; PreparedStatement rejected all 3 |
| **B2** damaged data | 8 different damaged lines | All detected with a reason; search still found the good records on both sides |
| **B3** insertion, 100,000 rows | Statement / PreparedStatement / batch / batch in one transaction | 115,479 ms / 13,304 ms / 13,493 ms / **995 ms** |
| **B3** transaction | invalid amount at record #1001 of 2,000 | auto-commit left 1,000 rows; single transaction left **0** rows |
| **B4** migration | 8,000-line legacy file | 7,995 loaded in 8 batches in one transaction, 5 rejected and reported |
| **B4** concurrency | 8 threads × 200 passes | text counter file: 92 distinct numbers (should be 1,600); database counter: 1,600 distinct |
| **B4** scale | 800,000 passes | text scan 228 ms/search; DB primary-key lookup 0.119 ms/search |
| **Decision** | | **Shared relational database** for the expanded 12-campus system |


## Output screenshots

Each screenshot is the real output of the program named in its caption (raw text is in `Task*/output/`).

### Task01 (B1) - file store
![B1 functional tests](Task01/screenshots/B1_01_store_functional_tests.png)
![B1 line-count benchmark](Task01/screenshots/B1_02_linecount_benchmark.png)
![B1 search benchmark](Task01/screenshots/B1_03_search_benchmark.png)

### Task02 (B2) - adversarial input
![B2 SQL injection login](Task02/screenshots/B2_01_sql_injection_login.png)
![B2 damaged data](Task02/screenshots/B2_02_damaged_data.png)

### Task03 (B3) - JDBC performance
![B3 loader and metadata](Task03/screenshots/B3_01_loader_metadata_transaction_part1.png)
![B3 transaction experiment](Task03/screenshots/B3_01_loader_metadata_transaction_part2.png)
![B3 insert benchmark](Task03/screenshots/B3_02_insert_benchmark.png)

### Task04 (B4) - final decision
![B4 migration](Task04/screenshots/B4_01_migration.png)
![B4 concurrency](Task04/screenshots/B4_02_concurrency.png)
![B4 scale benchmark](Task04/screenshots/B4_03_scale_benchmark.png)

The full written report with Part A is in `docs/Assignment5_CO5_Report.docx`.

## Notes and honest limitations

* The assignment says MySQL. The sandbox used to produce these measurements had no MySQL server and no access to Maven Central, so the JDBC tasks were executed on **embedded Apache Derby**. All SQL is portable and `Db.java` switches to MySQL via `-Ddb.url`. Absolute times will differ on MySQL (network round trips make batching matter more); the *relative* conclusions are the same. Re-run the three JDBC benchmarks on your MySQL instance before submission if your faculty insists on MySQL numbers, and add those screenshots.
* Measurements were taken on a small 2-vCPU container. Treat the numbers as evidence of *shape* (linear vs constant, orders of magnitude), not as a benchmark of your machine. Small sizes show JIT warm-up noise (e.g. the n = 5,000 point in the search chart).
* `Task01/PassStore.find()` is TODO 1, `PassLoader.loadStatement/loadPrepared/loadBatch` are TODO 1–3 of B3. The original TODO skeleton files were not part of the supplied PDF, so these classes were written from the task descriptions; if your faculty supplied skeleton files, paste the bodies of those methods into them.
* Part A pseudocode is in the report because the assignment states Java code is not a substitute for pseudocode.
